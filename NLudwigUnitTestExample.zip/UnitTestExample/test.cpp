// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
/*
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
*/

TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_TRUE(collection->size() == 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    size_t starting_size = collection->size();
    add_entries(5);
    ASSERT_TRUE(collection->size() == starting_size + 5);
}

TEST_F(CollectionTest, MaxSizeCheckVector)
{
    ASSERT_TRUE(collection->max_size() >= collection->size());
    add_entries(1);
    ASSERT_TRUE(collection->max_size() >= collection->size());
    add_entries(4);
    ASSERT_TRUE(collection->max_size() >= collection->size());
    add_entries(5);
    ASSERT_TRUE(collection->max_size() >= collection->size());
}
    

TEST_F(CollectionTest, CapacityCheckVector)
{
    ASSERT_TRUE(collection->capacity() >= collection->size());
    add_entries(1);
    ASSERT_TRUE(collection->capacity() >= collection->size());
    add_entries(4);
    ASSERT_TRUE(collection->capacity() >= collection->size());
    add_entries(5);
    ASSERT_TRUE(collection->capacity() >= collection->size());
}

TEST_F(CollectionTest, ResizeIncreaseVector)
{
    add_entries(5);
    collection->resize(10);
    ASSERT_TRUE(collection->size() == 10);
}

TEST_F(CollectionTest, ResizeDecreaseVector)
{
    add_entries(5);
    collection->resize(2);
    ASSERT_TRUE(collection->size() == 2);
}

TEST_F(CollectionTest, ResizeZeroVector)
{
    add_entries(5);
    collection->resize(0);
    ASSERT_TRUE(collection->size() == 0);
}

TEST_F(CollectionTest, ClearCheckVector)
{
    add_entries(2);
    collection->clear();
    ASSERT_TRUE(collection->size() == 0);
}

TEST_F(CollectionTest, EraseCheckVector)
{
    add_entries(2);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->size() == 0);
}

TEST_F(CollectionTest, ReserveCheckVector)
{
    size_t initial_capacity = collection->capacity();
    size_t initial_size = collection->size();
    collection->reserve(10);
    ASSERT_TRUE(collection->capacity() > initial_capacity);
    ASSERT_FALSE(collection->size() > initial_size);
}


// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeVector)
{
    add_entries(5);
    try
    {
        std::cout << collection->at(collection->size() + 1);
        FAIL();
    }
    catch (const std::out_of_range& ex)
    {
        //passed
    }
    catch (...)
    {
        //other exception type was given
        FAIL();
    }
    
}

TEST_F(CollectionTest, AddKeepsValueVector)
{
    add_entries(10);
    int value = rand() % 100;
    collection->push_back(value);
    ASSERT_TRUE(collection->back() == value);
}

TEST_F(CollectionTest, SwapVector)
{
    const size_t SIZE = 5;
    int values[SIZE] = {};
    for (int i = 0; i < SIZE; i++)
    {
        values[i] = rand() % 100;
        collection->push_back(values[i]);
    }
    std::vector<int> new_collection;
    for (int i = 0; i < SIZE; i++)
    {
        new_collection.push_back(200 + (rand() % 100));
    }
    collection->swap(new_collection);
    //fail if any values are the same. 0-100 and 200-300 shouldn't overlap
    for (int i = 0; i < collection->size(); i++)
    {
        if (collection->at(i) == values[i])
        {
            FAIL();
        }
    }
}