// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

class CustomException : public std::exception {
    private:
        const char message[30] = "This is a custom exception!";
    public:
        const char* what () 
        {
            return message;
        }
};

bool do_even_more_custom_application_logic()
{\
  throw std::invalid_argument( "Invalid argument given! This is bad!" );
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}
void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;
  try
  {   
    if(do_even_more_custom_application_logic())
    {
    std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  } 
  catch (const std::exception& ex) 
  {
    std::cout << "Even More Custom Application Logic Failed!" << std::endl;
    std::cout << ex.what() << std::endl;
  }

  throw CustomException();

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  if (den == 0)
  {
    throw std::runtime_error("Error, Divide by zero detected!");
  }
  return (num / den);
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;
  try
  {
  auto result = divide(numerator, denominator);
  std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::runtime_error& ex)
  {
      std::cout << "Was unable to do division. Error detected" << std::endl;
      std::cout << ex.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;
  try
  {
    do_division();
    do_custom_application_logic();
  }
  catch ( CustomException& ex )
  {
    std::cout << "Custom exception detected:" << std::endl;
    std::cout << ex.what() << std::endl;
  }
  catch ( const std::exception& ex )
  {
    std::cout << "Standard exception detected:" << std::endl;
    std::cout << ex.what() << std::endl;
  }
  catch ( ... )
  {
    std::cout << "Other exception detected." << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu